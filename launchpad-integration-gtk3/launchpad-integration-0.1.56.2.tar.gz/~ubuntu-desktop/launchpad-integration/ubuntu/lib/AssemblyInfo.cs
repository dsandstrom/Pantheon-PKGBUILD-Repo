using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle ("launchpad-integration-sharp")]
[assembly: AssemblyDescription ("C# client library for Launchpad integration")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("/usr/share/cli-common/keys/mono.snk")]
