#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <pygobject.h>
 
void pylpi_register_classes (PyObject *d); 
extern PyMethodDef pylpi_functions[];
 
DL_EXPORT (void)
init_lpi (void)
{
    PyObject *m, *d;
    
    m = Py_InitModule ("_lpi", pylpi_functions);
    d = PyModule_GetDict (m);
    
    init_pygobject ();
    
    pylpi_register_classes (d);
    
    if (PyErr_Occurred ())
        Py_FatalError ("can't initialise module lpi");
}
