#!/bin/sh

srcdir=`dirname $0`
test -z "$srcdir" && srcdir=.

ORIGDIR=`pwd`
cd $srcdir

libtoolize --force --copy || exit $?
autopoint --force || exit $?
aclocal -I m4 $ACLOCAL_FLAGS || exit $?
autoconf || exit $?
autoheader || exit $?
automake -c -a || exit $?

cd "$ORIGDIR"

$srcdir/configure --enable-maintainer-mode "$@" || exit $?
